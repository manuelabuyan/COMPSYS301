
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <project.h>
#include <stdlib.h>

#define MAP_WIDTH  19
#define MAP_HEIGHT 15
#define MAX 255

typedef struct nodes {
	uint8 x, y;
	uint8 gScore;
	uint8 fScore;
	uint8 hScore;
	uint8 movable;
	struct nodes *prev;
	struct nodes *neighbours[4];
} node;

struct sets {
	node *closedSet[MAP_HEIGHT*MAP_WIDTH];
	node *openSet[MAP_HEIGHT*MAP_WIDTH];
};

struct path {
	uint8 path_x[MAP_HEIGHT*MAP_WIDTH];
	uint8 path_y[MAP_HEIGHT*MAP_WIDTH];
	uint8 size;
};

struct path p;
node n[MAP_HEIGHT][MAP_WIDTH];
uint8 control_signals[50];
node* endNode;
void generateMap();
void initStruct();
void initAstar(uint8 s2, uint8 s1, uint8 e2, uint8 e1);
uint8 heuristic_cost_estimate(node *n1, node *n2);
void computePath(node *target);
uint8 existInSet(node *n, node* set[MAP_HEIGHT*MAP_WIDTH], uint8 size);
uint8 isNotEmpty(node* set[MAP_HEIGHT*MAP_WIDTH], uint8 size);
void setControl();