// aStar.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string.h>
#include <stdlib.h>
#define MAP_WIDTH  19
#define MAP_HEIGHT 15
#define MAX 10000
typedef struct nodes {
	int x, y;
	int gScore;
	int fScore;
	int hScore;
	int movable;
	struct nodes *prev;
	struct nodes *neighbours[4];
} node;

struct sets {
	node *closedSet[MAP_HEIGHT*MAP_WIDTH];
	node *openSet[MAP_HEIGHT*MAP_WIDTH];
};

struct path {
	int path_x[MAP_HEIGHT*MAP_WIDTH];
	int path_y[MAP_HEIGHT*MAP_WIDTH];
	int size;
};

struct path p;
node n[MAP_HEIGHT][MAP_WIDTH];
char map[MAP_HEIGHT][MAP_WIDTH];
int control_signals[50];


void generateMap();
void initStruct();
void initAstar(int s2, int s1, int e2, int e1);
int heuristic_cost_estimate(node *n1, node *n2);
void computePath(node *target);
int existInSet(node *n, node* set[MAP_HEIGHT*MAP_WIDTH], int size);
int isNotEmpty(node* set[MAP_HEIGHT*MAP_WIDTH], int size);
void setControl();

int main()
{	
	generateMap();
	initAstar(9,7,3,7);
	setControl();
    return 0;
}

void setControl()
{
	FILE *fp;
	int i;
	int direction;
	int prevX;
	int prevY;

	if (p.path_x[p.size - 2] > p.path_x[p.size - 1])
	{
		direction = 0; // RIGHT
	}
	else if (p.path_x[p.size - 2] < p.path_x[p.size - 1])
	{
		direction = 1; // LEFT
	}
	else if (p.path_y[p.size - 2] > p.path_y[p.size - 1])
	{
		direction = 2; // DOWN
	}
	else if (p.path_y[p.size - 2] < p.path_y[p.size - 1])
	{
		direction = 3; // UP
	}

	for (i = p.size - 1; i > 0; i--)
	{
		if (i == 1)
		{
			control_signals[p.size - i - 1] = 0;
			continue;
		}
		prevX = p.path_x[i - 2];
		prevY = p.path_y[i - 2];
		switch (direction) {
		case 0:
			if (prevY > p.path_y[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 2;
			}
			else if (prevY < p.path_y[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 3;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		case 1:
			if (prevY < p.path_y[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 3;
			}
			else if (prevY > p.path_y[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 2;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		case 2:
			if (prevX < p.path_x[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 1;
			}
			else if (prevX > p.path_x[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 0;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		case 3:
			if (prevX > p.path_x[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 0;
			}
			else if (prevX < p.path_x[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 1;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		}
	}
	fp = fopen("output.txt", "w");
	for (i = 0; i < p.size - 1; i++)
	{
		if (control_signals[i] == 0)
		{
			fprintf(fp, "Straight\n");
		}
		else if (control_signals[i] == 1)
		{
			fprintf(fp, "Turn right\n");
		}
		else if (control_signals[i] == 2)
		{
			fprintf(fp, "Turn left\n");
		}
	}
	fclose(fp);
}

void initStruct()
{
	int i, j;
	for (i = 0; i < MAP_HEIGHT - 1; i++)
	{
		for (j = 0; j < MAP_WIDTH - 1; j++)
		{
			n[i][j].x = j;
			n[i][j].y = i;
			n[i][j].neighbours[0] = &n[i + 1][j]; // TOP
			n[i][j].neighbours[1] = &n[i][j + 1]; // RIGHT
			n[i][j].neighbours[2] = &n[i - 1][j]; // BOTTOM
			n[i][j].neighbours[3] = &n[i][j - 1]; // LEFT

			n[i][j].gScore = MAX;
			n[i][j].fScore = MAX;
			n[i][j].hScore = MAX;
			n[i][j].prev = 0;
			n[i][j].movable = !(map[i][j] - 48);
		}
	}
}

int heuristic_cost_estimate(node *n1, node *n2)
{
	return abs(n1->x - n2->x) + abs(n1->y - n2->y);
}

node* lowest_fScore(node *set[MAP_HEIGHT*MAP_WIDTH], int size)
{
	int i;
	node *lowest = set[0];
	for (i = 1; i < size; i++)
	{
		if (set[i]->fScore < lowest->fScore)
		{
			lowest = set[i];
		}
	}
	return lowest;
}

void removeFromSet(node* n, node* set[MAP_HEIGHT*MAP_WIDTH], int size)
{
	int i;
	node* temp;
	for (i = 0; i < size; i++)
	{
		if (set[i] == n)
		{
			if (i != size - 1)
			{
				temp = set[size - 1];
				set[size - 1] = 0;
				set[i] = temp;
			}
			else
			{
				set[i] = 0;
			}
			break;
		}
	}
}

void initAstar(int s2, int s1, int e2, int e1)
{
	struct sets s;
	int i;
	int closeSetCount = 0;
	int openSetCount = 1;
	node *current;
	initStruct();
	s.openSet[0] = &n[s1][s2];
	n[s1][s2].gScore = 0;
	n[s1][s2].fScore = heuristic_cost_estimate(&n[s1][s2], &n[e1][e2]);

	while (isNotEmpty(s.openSet, openSetCount))
	{
		current = lowest_fScore(s.openSet, openSetCount);
		if (current == &n[e1][e2])
		{
			break;
		}

		removeFromSet(current,s.openSet, openSetCount);
		openSetCount--;
		s.closedSet[closeSetCount] = current;
		closeSetCount++;

		for (i = 0; i < 4; i++)
		{
			if (current->neighbours[i] == 0 || current->neighbours[i]->movable == 0)
			{
				continue;
			}

			if (existInSet(current->neighbours[i], s.closedSet, closeSetCount))
			{
				continue;
			}

			if (!existInSet(current->neighbours[i], s.openSet, openSetCount))
			{
				s.openSet[openSetCount] = current->neighbours[i];
				openSetCount++;
			}
			else if (current->gScore + 1 >= current->neighbours[i]->gScore)
			{
				continue;
			}
			current->neighbours[i]->prev = current;
			current->neighbours[i]->gScore = current->gScore + 1;
			current->neighbours[i]->fScore = current->neighbours[i]->gScore + heuristic_cost_estimate(current->neighbours[i], &n[e1][e2]);
		}
	}
	computePath(&n[e1][e2]);
}

void computePath(node *target)
{
	FILE *fp;
	int i = 0;
	p.size = 0;
	node *current = target;
	fp = fopen("output.txt", "w");
	while (current != 0)
	{
		p.path_x[i] = current->x;
		p.path_y[i] = current->y;
		p.size++;
		i++;
		fprintf(fp, "X : %d , Y : %d", current->x, current->y);
		fprintf(fp, "\n");
		current = current->prev;
	}
	fprintf(fp, "\n");
	fclose(fp);
}

int isNotEmpty(node* set[MAP_HEIGHT*MAP_WIDTH], int size)
{
	int i;
	for (i = 0; i < size; i++)
	{
		if (set[i] != 0)
		{
			return 1;
		}
	}
	return 0;
}

int existInSet(node* n, node* set[MAP_HEIGHT*MAP_WIDTH], int size)
{
	int i;
	for (i = 0; i < size; i++)
	{
		if (set[i] == n)
		{
			return 1;
		}
	}
	return 0;
}

void generateMap()
{
	FILE *fp;
	int i = 0, j = 0;
	char c;
	fp = fopen("current_map.txt", "r");
	while ((c = fgetc(fp)) != EOF)
	{
		if (c == '\n')
		{
			j = 0;
			i++;
		}
		else
		{
			map[i][j] = c;
			j++;
		}
	}
	fclose(fp);
}

