// aStar.cpp : Defines the entry point for the console application.
//
#include <astar.h>

uint8 map[MAP_HEIGHT][MAP_WIDTH] = {  
 /* 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 */
   {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1} , // 0
   {1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1} , // 1
   {1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1} , // 2 
   {1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1} , // 3 
   {1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1} , // 4 
   {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1} , // 5 
   {1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1} , // 6 
   {1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1} , // 7 
   {1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1} , // 8 
   {1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1} , // 9 
   {1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1} , // 10 
   {1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1} , // 11 
   {1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1} , // 12 
   {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1} , // 13 
   {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}   // 14 
 /* 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 */
};

void setControl()
{
	uint8 i;
	uint8 direction;
	uint8 prevX;
	uint8 prevY;

	if (p.path_x[p.size - 2] > p.path_x[p.size - 1])
	{
		direction = 0; // RIGHT
	}
	else if (p.path_x[p.size - 2] < p.path_x[p.size - 1])
	{
		direction = 1; // LEFT
	}
	else if (p.path_y[p.size - 2] > p.path_y[p.size - 1])
	{
		direction = 2; // DOWN
	}
	else if (p.path_y[p.size - 2] < p.path_y[p.size - 1])
	{
		direction = 3; // UP
	}

	for (i = p.size - 1; i > 1; i--)
	{
        prevX = p.path_x[i - 2];
		prevY = p.path_y[i - 2];
		switch (direction) {
		case 0:
			if (prevY > p.path_y[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 2;
			}
			else if (prevY < p.path_y[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 3;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		case 1:
			if (prevY < p.path_y[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 3;
			}
			else if (prevY > p.path_y[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 2;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		case 2:
			if (prevX < p.path_x[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 1;
			}
			else if (prevX > p.path_x[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 0;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		case 3:
			if (prevX > p.path_x[i])
			{
				control_signals[p.size - i - 1] = 1; // Turn right
				direction = 0;
			}
			else if (prevX < p.path_x[i])
			{
				control_signals[p.size - i - 1] = 2; // Turn left
				direction = 1;
			}
			else
			{
				control_signals[p.size - i - 1] = 0; // Straight
			}
			break;
		}
	}
}

void initStruct()
{
	uint8 i, j;
	for (i = 0; i < MAP_HEIGHT; i++)
	{
		for (j = 0; j < MAP_WIDTH; j++)
		{
			n[i][j].x = j;
			n[i][j].y = i;

			if (i != 0)
			{
				n[i][j].neighbours[0] = &n[i + 1][j]; // TOP
			}
			else
			{
				n[i][j].neighbours[0] = 0;
			}
			if (i != 14)
			{
				n[i][j].neighbours[2] = &n[i - 1][j]; // BOTTOM
			}
			else
			{
				n[i][j].neighbours[2] = 0;
			}
			if (j != 0)
			{
				n[i][j].neighbours[3] = &n[i][j - 1]; // LEFT
			}
			else
			{
				n[i][j].neighbours[3] = 0;
			}
			if (j != 18)
			{
				n[i][j].neighbours[1] = &n[i][j + 1]; // RIGHT
			}
			else
			{
				n[i][j].neighbours[1] = 0;
			}

			n[i][j].gScore = MAX;
			n[i][j].fScore = MAX;
			n[i][j].hScore = MAX;
			n[i][j].prev = 0;
			n[i][j].movable = !(map[i][j]);
		}
	}
}

uint8 heuristic_cost_estimate(node *n1, node *n2)
{
	return abs(n1->x - n2->x) + abs(n1->y - n2->y);
}

node* lowest_fScore(node *set[MAP_HEIGHT*MAP_WIDTH], uint8 size)
{
	uint8 i;
	node *lowest = set[0];
	for (i = 1; i < size; i++)
	{
		if (set[i]->fScore < lowest->fScore)
		{
			lowest = set[i];
		}
	}
	return lowest;
}

void removeFromSet(node* n, node* set[MAP_HEIGHT*MAP_WIDTH], uint8 size)
{
	uint8 i;
	node* temp;
	for (i = 0; i < size; i++)
	{
		if (set[i] == n)
		{
			if (i != size - 1)
			{
				temp = set[size - 1];
				set[size - 1] = 0;
				set[i] = temp;
			}
			else
			{
				set[i] = 0;
			}
			break;
		}
	}
}

void initAstar(uint8 s2, uint8 s1, uint8 e2, uint8 e1)
{
	// start location = s,s
	// current location = c,c
	// end location = e,e
	// neighbour-end location = n,e
    initStruct();
	struct sets s;
	uint8 i;
	uint8 closeSetCount = 0;
	uint8 openSetCount = 1;
	node *current;
	s.openSet[0] = &n[s1][s2];
	n[s1][s2].gScore = 0;
	n[s1][s2].fScore = heuristic_cost_estimate(&n[s1][s2], &n[e1][e2]);

	while (isNotEmpty(s.openSet, openSetCount))
	{
		current = lowest_fScore(s.openSet, openSetCount);
		if (current == &n[e1][e2])
		{
			break;
		}

		removeFromSet(current,s.openSet, openSetCount);
		openSetCount--;
		s.closedSet[closeSetCount] = current;
		closeSetCount++;

		for (i = 0; i < 4; i++)
		{
			if (current->neighbours[i] == 0 || current->neighbours[i]->movable == 0)
			{
				continue;
			}

			if (existInSet(current->neighbours[i], s.closedSet, closeSetCount))
			{
				continue;
			}

			if (!existInSet(current->neighbours[i], s.openSet, openSetCount))
			{
				s.openSet[openSetCount] = current->neighbours[i];
				openSetCount++;
			}
			else if (current->gScore + 1 >= current->neighbours[i]->gScore)
			{
				continue;
			}
			current->neighbours[i]->prev = current;
			current->neighbours[i]->gScore = current->gScore + 1;
			current->neighbours[i]->fScore = current->neighbours[i]->gScore + heuristic_cost_estimate(current->neighbours[i], &n[e1][e2]);
		}
	}
	computePath(&n[e1][e2]);
}

void computePath(node *target)
{
	uint8 i = 0;
	p.size = 0;
	node *current = target;
	while (current != 0)
	{
		p.path_x[i] = current->x;
		p.path_y[i] = current->y;
		p.size++;
		i++;
		current = current->prev;
	}
}

uint8 isNotEmpty(node* set[MAP_HEIGHT*MAP_WIDTH], uint8 size)
{
	uint8 i;
	for (i = 0; i < size; i++)
	{
		if (set[i] != 0)
		{
			return 1;
		}
	}
	return 0;
}

uint8 existInSet(node* n, node* set[MAP_HEIGHT*MAP_WIDTH], uint8 size)
{
	uint8 i;
	for (i = 0; i < size; i++)
	{
		if (set[i] == n)
		{
			return 1;
		}
	}
	return 0;
}

